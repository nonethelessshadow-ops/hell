package com.chessvision.overlay

import android.content.Context
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.abs

interface OverlayHost {
    fun isMini(): Boolean
    fun headerPx(): Int
    fun dragWidthPx(): Int
    fun posX(): Int
    fun posY(): Int
    fun sizeW(): Int
    fun sizeH(): Int
    fun moveTo(x: Int, y: Int)
    fun resizeTo(w: Int, h: Int)
    fun restore()
    fun commit()
}

/**
 * Root view of the floating window. It grabs touches that start on the header drag strip,
 * the bottom-right resize grip, or anywhere on the minimized bubble, and moves/resizes the
 * real window. Every other touch goes to the WebView.
 */
class OverlayRoot(ctx: Context, private val host: OverlayHost) : FrameLayout(ctx) {

    private var mode = 0 // 0 = pass to WebView, 1 = drag, 2 = resize, 3 = bubble
    private var downX = 0f
    private var downY = 0f
    private var x0 = 0
    private var y0 = 0
    private var w0 = 0
    private var h0 = 0
    private var moved = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val grip = (30 * ctx.resources.displayMetrics.density).toInt()

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            mode = when {
                host.isMini() -> 3
                ev.x > width - grip && ev.y > height - grip -> 2
                ev.y < host.headerPx() && ev.x < host.dragWidthPx() -> 1
                else -> 0
            }
            if (mode != 0) {
                downX = ev.rawX
                downY = ev.rawY
                x0 = host.posX()
                y0 = host.posY()
                w0 = host.sizeW()
                h0 = host.sizeH()
                moved = false
                return true
            }
        }
        return false
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (mode == 0) return false
        val dx = (ev.rawX - downX).toInt()
        val dy = (ev.rawY - downY).toInt()
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                if (!moved && (abs(dx) > slop || abs(dy) > slop)) moved = true
                if (moved) {
                    if (mode == 2) {
                        host.resizeTo(w0 + dx, h0 + dy)
                    } else {
                        host.moveTo(x0 + dx, y0 + dy)
                    }
                }
            }
            MotionEvent.ACTION_UP -> {
                if (mode == 3 && !moved) {
                    host.restore()
                } else {
                    host.commit()
                }
                mode = 0
            }
            MotionEvent.ACTION_CANCEL -> {
                host.commit()
                mode = 0
            }
        }
        return true
    }
}

package com.chessvision.overlay

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import androidx.webkit.WebViewAssetLoader
import kotlin.math.max
import kotlin.math.min

class OverlayService : Service(), OverlayHost {

    companion object {
        const val ACTION_STOP = "com.chessvision.overlay.STOP"
        private const val CHANNEL = "overlay"
        private const val NOTIF_ID = 17
    }

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var root: OverlayRoot? = null
    private var web: WebView? = null
    private var bubble: TextView? = null
    private val ui = Handler(Looper.getMainLooper())

    private var mini = false
    private var fit = false
    private var saved = intArrayOf(0, 0, 0, 0) // x, y, w, h of the normal (not fit / not mini) window
    private var hdrPx = 0
    private var dragPx = 0

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun bounds(): Rect {
        if (Build.VERSION.SDK_INT >= 30) {
            return wm.maximumWindowMetrics.bounds
        }
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        return Rect(0, 0, m.widthPixels, m.heightPixels)
    }

    private fun sw(): Int = bounds().width()
    private fun sh(): Int = bounds().height()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (root == null) {
            if (!Settings.canDrawOverlays(this)) {
                stopSelf()
                return START_NOT_STICKY
            }
            createOverlay()
        }
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("ChessVision overlay is running")
            .setContentText("Tap to open settings")
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createOverlay() {
        val prefs = getSharedPreferences("geom", MODE_PRIVATE)
        val w = max(dp(200), min(prefs.getInt("w", dp(360)), sw()))
        val h = max(dp(240), min(prefs.getInt("h", dp(600)), sh() - dp(40)))
        val x = prefs.getInt("x", (sw() - w) / 2)
        val y = prefs.getInt("y", dp(40))
        saved = intArrayOf(x, y, w, h)

        lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        lp.x = max(0, min(x, sw() - w))
        lp.y = max(0, min(y, sh() - h))

        val nativeJs = assets.open("native.js").bufferedReader().use { it.readText() }
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        val wv = WebView(this)
        wv.setBackgroundColor(Color.TRANSPARENT)
        wv.overScrollMode = View.OVER_SCROLL_NEVER
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.allowFileAccess = false
        wv.settings.allowContentAccess = false
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)

            override fun onPageFinished(view: WebView, url: String?) {
                view.evaluateJavascript(nativeJs, null)
            }
        }
        wv.addJavascriptInterface(Bridge(), "Android")

        val bub = TextView(this)
        bub.text = "\u265E\uFE0E"
        bub.textSize = 28f
        bub.setTextColor(Color.WHITE)
        bub.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.parseColor("#16A34A"))
        bub.background = bg
        bub.visibility = View.GONE

        val r = OverlayRoot(this, this)
        r.addView(wv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        r.addView(bub, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        web = wv
        bubble = bub
        root = r
        wm.addView(r, lp)
        wv.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    /* ---------- OverlayHost ---------- */

    override fun isMini(): Boolean = mini
    override fun headerPx(): Int = if (hdrPx > 0) hdrPx else dp(44)
    override fun dragWidthPx(): Int = if (dragPx > 0) dragPx else dp(180)
    override fun posX(): Int = lp.x
    override fun posY(): Int = lp.y
    override fun sizeW(): Int = lp.width
    override fun sizeH(): Int = lp.height

    private fun push() {
        val r = root ?: return
        wm.updateViewLayout(r, lp)
    }

    override fun moveTo(x: Int, y: Int) {
        lp.x = max(0, min(x, sw() - lp.width))
        lp.y = max(0, min(y, sh() - lp.height))
        push()
    }

    override fun resizeTo(w: Int, h: Int) {
        if (mini || fit) return
        lp.width = max(dp(200), min(w, sw() - lp.x))
        lp.height = max(dp(240), min(h, sh() - lp.y))
        push()
    }

    override fun commit() {
        if (mini || fit) return
        getSharedPreferences("geom", MODE_PRIVATE).edit()
            .putInt("x", lp.x)
            .putInt("y", lp.y)
            .putInt("w", lp.width)
            .putInt("h", lp.height)
            .apply()
    }

    override fun restore() {
        mini = false
        lp.width = saved[2]
        lp.height = saved[3]
        lp.x = max(0, min(lp.x, sw() - lp.width))
        lp.y = max(0, min(lp.y, sh() - lp.height))
        bubble?.visibility = View.GONE
        web?.visibility = View.VISIBLE
        push()
        commit()
    }

    private fun minimize() {
        if (mini) return
        if (!fit) saved = intArrayOf(lp.x, lp.y, lp.width, lp.height)
        fit = false
        mini = true
        setFocusableFlag(false)
        val size = dp(52)
        lp.width = size
        lp.height = size
        lp.x = max(0, min(lp.x, sw() - size))
        lp.y = max(0, min(lp.y, sh() - size))
        web?.visibility = View.GONE
        bubble?.visibility = View.VISIBLE
        push()
    }

    private fun toggleFit() {
        if (mini) return
        if (!fit) {
            saved = intArrayOf(lp.x, lp.y, lp.width, lp.height)
            fit = true
            lp.x = 0
            lp.y = 0
            lp.width = sw()
            lp.height = sh()
            push()
        } else {
            fit = false
            lp.x = saved[0]
            lp.y = saved[1]
            lp.width = saved[2]
            lp.height = saved[3]
            push()
            commit()
        }
    }

    private fun setFocusableFlag(on: Boolean) {
        val r = root ?: return
        val f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        lp.flags = if (on) (lp.flags and f.inv()) else (lp.flags or f)
        wm.updateViewLayout(r, lp)
        val w = web ?: return
        if (on) {
            w.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            ui.postDelayed({ imm.showSoftInput(w, InputMethodManager.SHOW_IMPLICIT) }, 120)
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun setZones(headerDp: Float, dragDp: Float) {
            val d = resources.displayMetrics.density
            ui.post {
                hdrPx = (headerDp * d).toInt()
                dragPx = (dragDp * d).toInt()
            }
        }

        @JavascriptInterface
        fun setFocusable(on: Boolean) {
            ui.post { setFocusableFlag(on) }
        }

        @JavascriptInterface
        fun minimize() {
            ui.post { this@OverlayService.minimize() }
        }

        @JavascriptInterface
        fun toggleFit() {
            ui.post { this@OverlayService.toggleFit() }
        }

        @JavascriptInterface
        fun close() {
            ui.post { stopSelf() }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (root == null) return
        if (fit) {
            lp.x = 0
            lp.y = 0
            lp.width = sw()
            lp.height = sh()
        } else {
            lp.width = min(lp.width, sw())
            lp.height = min(lp.height, sh())
            lp.x = max(0, min(lp.x, sw() - lp.width))
            lp.y = max(0, min(lp.y, sh() - lp.height))
        }
        push()
    }

    override fun onDestroy() {
        val r = root
        if (r != null) {
            try {
                wm.removeView(r)
            } catch (e: Exception) {
            }
            r.removeAllViews()
        }
        web?.destroy()
        root = null
        web = null
        bubble = null
        super.onDestroy()
    }
}

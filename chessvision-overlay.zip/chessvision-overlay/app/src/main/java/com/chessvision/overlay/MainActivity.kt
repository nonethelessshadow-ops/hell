package com.chessvision.overlay

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int): Int = (v * d).toInt()

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setBackgroundColor(Color.parseColor("#0B0D12"))
        col.setPadding(dp(24), dp(56), dp(24), dp(24))

        val title = TextView(this)
        title.text = "ChessVision"
        title.textSize = 28f
        title.setTextColor(Color.WHITE)
        col.addView(title)

        val help = TextView(this)
        help.text = "1. Allow \"Display over other apps\".\n2. Tap Start overlay.\n3. Open YouTube. The board floats on top: drag the header to move it, drag the bottom-right corner to resize, tap \u2013 to shrink it to a bubble."
        help.textSize = 15f
        help.setTextColor(Color.parseColor("#C9D1E0"))
        help.setPadding(0, dp(12), 0, dp(12))
        col.addView(help)

        status = TextView(this)
        status.textSize = 15f
        status.setTextColor(Color.parseColor("#FBBF24"))
        col.addView(status)

        fun btn(label: String, action: () -> Unit) {
            val b = Button(this)
            b.text = label
            b.setOnClickListener { action() }
            val p = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            p.topMargin = dp(12)
            col.addView(b, p)
        }

        btn("1. Allow overlay permission") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName))
            )
        }
        btn("2. Start overlay") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Allow the overlay permission first", Toast.LENGTH_LONG).show()
            } else {
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                startForegroundService(Intent(this, OverlayService::class.java))
                moveTaskToBack(true)
            }
        }
        btn("Stop overlay") {
            stopService(Intent(this, OverlayService::class.java))
        }

        setContentView(col)
    }

    override fun onResume() {
        super.onResume()
        status.text = if (Settings.canDrawOverlays(this)) {
            "Overlay permission: granted"
        } else {
            "Overlay permission: NOT granted"
        }
    }
}

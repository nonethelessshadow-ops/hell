/* Injected by OverlayService after index.html loads. Adapts the page to the native floating window. */
(function () {
  if (window.__cvNative) return;
  window.__cvNative = 1;
  var A = window.Android;
  if (!A) return;

  function $(id) { return document.getElementById(id); }

  var st = document.createElement('style');
  st.textContent =
    'html,body{background:transparent!important}' +
    '#win{left:0!important;top:0!important;width:100%!important;height:100%!important;box-shadow:none!important}';
  document.head.appendChild(st);

  /* tell the native side which strip of the header is draggable */
  function zones() {
    var h = $('hdr'), p = $('bPanel');
    if (h && p) A.setZones(h.offsetHeight, p.getBoundingClientRect().left);
  }

  /* minimize / fit are handled by the native window, not the page */
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('button');
    if (!b) return;
    if (b.id === 'bMin') { e.stopImmediatePropagation(); e.preventDefault(); A.minimize(); }
    else if (b.id === 'bFit') { e.stopImmediatePropagation(); e.preventDefault(); A.toggleFit(); }
  }, true);

  /* keyboard only works when the overlay window is focusable: enable it while the FEN box is active */
  var fe = $('fen');
  if (fe) {
    fe.addEventListener('focus', function () { A.setFocusable(true); });
    fe.addEventListener('blur', function () {
      setTimeout(function () { if (document.activeElement !== fe) A.setFocusable(false); }, 150);
    });
    document.addEventListener('pointerdown', function (e) {
      if (e.target !== fe && document.activeElement === fe) fe.blur();
    }, true);
  }

  /* close button */
  var hdr = $('hdr');
  if (hdr) {
    var c = document.createElement('button');
    c.className = 'ib';
    c.title = 'Close';
    c.textContent = '\u2715';
    c.onclick = function () { A.close(); };
    hdr.appendChild(c);
  }

  zones();
  addEventListener('resize', zones);
  if (window.ResizeObserver && hdr) new ResizeObserver(zones).observe(hdr);
})();

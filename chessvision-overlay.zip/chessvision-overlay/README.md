# ChessVision Overlay

Android app that shows your ChessVision HTML as a floating window on top of other apps (YouTube, etc.).
Your HTML runs unmodified; `app/src/main/assets/native.js` adapts it to the floating window.

## Setup
1. Put your ChessVision HTML at `app/src/main/assets/index.html` (replace the placeholder).
2. Optional: add a single-file `stockfish.js` (asm.js build) next to it in `assets/` for the Stockfish engine. Without it the built-in engine is used.
3. Push to GitHub on the `main` branch. The "Build APK" workflow runs automatically.
4. Download the APK from the repo's **Releases → Latest build** (or Actions → latest run → Artifacts) and install it.

## On the phone
1. Open ChessVision, tap "Allow overlay permission", enable it for ChessVision.
2. Tap "Start overlay", then open YouTube.
3. Drag the header to move, drag the bottom-right corner to resize, – shrinks to a bubble (tap it to restore), ⤢ toggles full screen, ✕ closes.

## Updating
Replace `app/src/main/assets/index.html` and push. Builds are signed with a fixed key, so new APKs install over old ones.
